<?php include 'header.php'; ?> <html>
<title>Index</title>


	 </html><?php include 'index_bienvenue.php'; ?> <html>

    </html><?php include 'index_articles.php'; ?> <html>

    </html><?php include 'index_numbers.php'; ?> <html>

    </html><?php  include 'index_partenaires.php'; ?> <html>

	  </html><?php include 'footer.php'; ?> <html>
</body>	
</html>