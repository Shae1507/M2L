<?php include 'header.php'; ?> <html>
<title>Nos services</title>

	      <div class="main">
	      	  <div class="shop_top">
	      			<div class="container">
<h3 class="western" style="color: #FF4500">Services propos&eacute;s aux ligues par la M2L</h3>
<p class="western">&nbsp;</p>
<h4 class="western"><strong>Acc&egrave;s Internet</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Les ligues disposent d'un acc&egrave;s Internet mutualis&eacute; que la M2L loue &agrave; un prestataire ext&eacute;rieur.</span></p>
<p class="western" align="justify">&nbsp;</p>
<h4 class="western"><strong>Acc&egrave;s Wifi</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Dans tous les espaces, un r&eacute;seau Wifi "visiteurs" est disponible, avec une cl&eacute; WPA renouvel&eacute;e r&eacute;guli&egrave;rement et communiqu&eacute;e aux ligues. Ce r&eacute;seau ne permet que l'acc&egrave;s &agrave; Internet.</span></p>
<p class="western" align="justify">&nbsp;</p>
<h4 class="western"><strong>T&eacute;l&eacute;phonie</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Dans les b&acirc;timents anciens A et B, les salles et bureaux sont &eacute;quip&eacute;s de prises de t&eacute;l&eacute;phone analogiques. La M2L y fournit les combin&eacute;s t&eacute;l&eacute;phoniques. Dans les b&acirc;timents neufs C et D, l'&eacute;quipement t&eacute;l&eacute;phonique est de type VoIP. La M2L loue des postes t&eacute;l&eacute;phoniques IP aux ligues.</span></p>
<p class="western" align="justify">&nbsp;</p>
<h4 class="western"><strong>Affranchissement</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Une machine &agrave; affranchir permet un affranchissement rapide et en nombre. Cette prestation est factur&eacute;e aux ligues au co&ucirc;t de l'affranchissement. Chaque mois, on relie la machine &agrave; affranchir &agrave; une imprimante pour obtenir une liste de codes de gestion correspondant aux ligues associ&eacute;s &agrave; une quantit&eacute; et un type d'affranchissement. La prise en compte de ces informations permet au CROSL d'&eacute;diter des factures.</span></p>
<h4 class="western">&nbsp;</h4>
<h4 class="western"><strong> Impressions en volume et en qualit&eacute; imprimerie</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Les ligues disposent de la possibilit&eacute; d'imprimer sur des ressources d'impression num&eacute;riques connect&eacute;es situ&eacute;es dans le local reprographie du rez-de-chauss&eacute;e dont l'usage fait l'objet d'une facturation &agrave; prix co&ucirc;tant. Un syst&egrave;me de comptage situ&eacute; sur le serveur d'impression permet au CROSL d&rsquo;effectuer une facturation mensuelle aupr&egrave;s des ligues.</span></p>
<ul>
<ul>
<li>une photocopieuse noir et blanc &agrave; 70 pages/minute avec diff&eacute;rents dispositifs de finition,</li>
</ul>
</ul>
<ul>
<ul>
<li>une imprimante Laser couleur A4/A3 &agrave; encre solide &agrave; 25 pages/minute,</li>
</ul>
</ul>
<ul>
<ul>
<li>un traceur A2 (1 page / minute) utilis&eacute; pour les affiches et banderoles.</li>
</ul>
</ul>
<p class="western"><br /><br /></p>
<h4 class="western"><strong>Serveur FTP documentaire</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">La M2L met &agrave; disposition des ligues un serveur FTP documentaire intranet/internet regroupant des textes l&eacute;gaux, des mod&egrave;les de dossiers, de statuts, des programmes de formation (...) compil&eacute;s par le CROSL.</span></p>
<p class="western" align="justify">&nbsp;</p>
<h4 class="western"><strong>Syst&egrave;me de r&eacute;servation des salles</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">La M2L met &agrave; disposition des ligues un site web de r&eacute;servation des salles (r&eacute;unions, amphith&eacute;&acirc;tre, restauration). Ce site est accessible en intranet, mais aussi depuis l'internet. Les r&eacute;servations payantes sont factur&eacute;es par la R&eacute;gion aux utilisateurs. L&rsquo;administration de la M2L lui communique les informations n&eacute;cessaires &agrave; cette facturation de fa&ccedil;on hebdomadaire.</span></p>
<h4 class="western">&nbsp;</h4>
<h4 class="western"><strong>Information sur le digicode du jour et la cl&eacute; Wifi</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">La M2L met &agrave; disposition des ligues un site </span><span style="font-family: Calibri, sans-serif;"><em>web</em></span><span style="font-family: Calibri, sans-serif;"> d'information sur le digicode permettant l'acc&egrave;s &agrave; la M2L ainsi que sur la cl&eacute; Wifi "visiteurs". Le syst&egrave;me de r&eacute;servation donne &eacute;galement le digicode du jour dans le compte-rendu de r&eacute;servation envoy&eacute; automatiquement par mail.</span></p>
<h4 class="western" align="justify">&nbsp;</h4>
<h4 class="western" align="justify"><strong>Syst&egrave;me de gestion des configurations</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">M2L g&egrave;re &agrave; travers un logiciel de gestion des configurations l'ensemble du parc informatique incluant les postes fixes des ligues.</span></p>
<h4 class="western">&nbsp;</h4>
<h4 class="western"><strong>Int&eacute;gration des postes informatiques des ligues</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Lorsque les ligues acqui&egrave;rent du mat&eacute;riel informatique, il y a une phase obligatoire d'int&eacute;gration qui consiste &agrave;&nbsp;:</span></p>
<ul>
<ul>
<li>installer un antivirus affili&eacute; au serveur antiviral de la M2L,</li>
</ul>
</ul>
<ul>
<ul>
<li>installer la derni&egrave;re version de l'agent qui r&eacute;alise l&rsquo;inventaire mat&eacute;riel et logiciel</li>
</ul>
</ul>
<ul>
<ul>
<li>param&eacute;trer le poste en adressage IP automatique,</li>
</ul>
</ul>
<ul>
<ul>
<li>installer un syst&egrave;me de sauvegarde de donn&eacute;es sur un site FTP de sauvegarde g&eacute;r&eacute; par la M2L,</li>
</ul>
</ul>
<ul>
<ul>
<li>effectuer les derni&egrave;res mises &agrave; jour syst&egrave;mes et &agrave; param&eacute;trer leur automatisation,</li>
</ul>
</ul>
<ul>
<ul>
<li>param&eacute;trer les noms des postes selon les r&egrave;gles de gestion suivantes&nbsp;:</li>
<li>&nbsp;</li>
</ul>
</ul>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">B[code b&acirc;timent]E[num&eacute;ro &eacute;tage]L[num&eacute;ro ligue]S[num&eacute;ro salle].P[num&eacute;ro poste]</span></p>
<p class="western" align="justify">&nbsp;</p>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;"><strong>Code b&acirc;timent</strong></span><span style="font-family: Calibri, sans-serif;"> qui peut &ecirc;tre A ou C</span></p>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;"><strong>N&deg; &eacute;tage</strong></span><span style="font-family: Calibri, sans-serif;"> est compris entre 1 et 4 (puisque les locaux du rez-de-chauss&eacute;e n'h&eacute;bergent pas de ligues)</span></p>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;"><strong>N&deg; ligue </strong></span><span style="font-family: Calibri, sans-serif;">sur 2 chiffres : correspond &agrave; un nombre attribu&eacute; &agrave; la ligue allant pour l'instant de 01 &agrave; 24</span></p>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;"><strong>N&deg; salle</strong></span><span style="font-family: Calibri, sans-serif;"> sur 2 chiffres&nbsp;: correspond aux bureaux occup&eacute;s par les ligues</span></p>
<p class="western"><span style="font-family: Calibri, sans-serif;"><strong>N&deg; poste</strong></span><span style="font-family: Calibri, sans-serif;"> sur 2 chiffres&nbsp;: correspond au num&eacute;ro &eacute;crit sur la prise murale</span></p>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Exemple&nbsp;: le nom d'h&ocirc;te </span><span style="font-family: Calibri, sans-serif;"><strong>BAE2L06S01P01</strong></span><span style="font-family: Calibri, sans-serif;"> correspond au poste install&eacute; sur la prise N&deg;1 du bureau A201 occup&eacute; par la ligue de Volley, bureau situ&eacute; au deuxi&egrave;me &eacute;tage du b&acirc;timent A.</span></p>
<p class="western" align="justify">&nbsp;</p>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Cette int&eacute;gration est contractualis&eacute;e. Les ligues et CD &eacute;tant toutes des structures associatives ind&eacute;pendantes, leurs postes ne sont pas int&eacute;gr&eacute;s dans un annuaire central. Par contre, les postes de l'administration de la M2L et de la salle multim&eacute;dia le sont.</span></p>
<h4 class="western">&nbsp;</h4>
<h4 class="western">&nbsp;</h4>
<h4 class="western"><strong>Int&eacute;gration d'imprimantes</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Lorsque les structures h&eacute;berg&eacute;es s'&eacute;quipent d'imprimante r&eacute;seau, la connexion en est r&eacute;alis&eacute;e par l'informaticien b&eacute;n&eacute;vole du CROSL, sans passer par un serveur d'impression. Le nom de l'imprimante est lui aussi codifi&eacute; de la m&ecirc;me fa&ccedil;on que celui des postes (la lettre L vient remplacer la lettre P).</span></p>
<h4 class="western">&nbsp;</h4>
<h4 class="western"><strong>Service d'&eacute;tablissement de bulletins de salaire</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Le CRIB (Centre R&eacute;gional d'Information des B&eacute;n&eacute;voles) est un label donn&eacute; au CROSL qui, entre autres missions d'information (sur les textes r&eacute;glementaires, la convention nationale du sport ...), propose un service d'&eacute;tablissement de bulletins de salaires aux ligues et &agrave; leurs clubs affili&eacute;s. Le CROSL est tiers de confiance pour l'URSSAF et, &agrave; ce titre, &eacute;tablit des bulletins de salaires r&eacute;glementaires et tous les documents annexes. La prestation est factur&eacute;e au forfait (60 &euro; par an) et au bulletin &eacute;dit&eacute; (5 &euro;). Un employ&eacute; du CROSL est affect&eacute; &agrave; cette mission &agrave; raison de 0,8 ETP.</span></p>
<p class="western">&nbsp;</p>
<p class="western"><span style="font-family: Calibri, sans-serif;">Illustration du processus pour une ligue qui fait &eacute;tablir ses bulletins de salaires par le CRIB, pour des animateurs &agrave; la vacation, comme pour ses employ&eacute;s permanents.</span></p>
<p class="western">&nbsp;</p>
<p class="western"><span style="font-family: Calibri, sans-serif;">- La ligue &eacute;tablit une &laquo;&nbsp;d&eacute;claration unique d'embauche&nbsp;&raquo; et un contrat de travail.</span></p>
<p class="western">&nbsp;</p>
<p class="western"><span style="font-family: Calibri, sans-serif;">- Les donn&eacute;es "salaires" sont envoy&eacute;es par les associations au CRIB avant le 15 du mois :</span></p>
<ul>
<ul>
<li>Nom, pr&eacute;nom, date de naissance, adresse, n&deg; de s&eacute;cu, de l&rsquo;intervenant ou du salari&eacute;</li>
</ul>
</ul>
<ul>
<ul>
<li>Dates et heures d'intervention (de jour / de nuit)</li>
</ul>
</ul>
<ul>
<ul>
<li>Heures cong&eacute;s pay&eacute;es associ&eacute;es</li>
</ul>
</ul>
<ul>
<ul>
<li>Taux horaire</li>
</ul>
</ul>
<ul>
<ul>
<li>Intitul&eacute; dans la grille de la <span style="font-family: Calibri, sans-serif;"><em>convention nationale du sport</em></span><span style="font-family: Calibri, sans-serif;"> (exemple&nbsp;: technicien niveau 3)</span></li>
</ul>
</ul>
<p class="western">&nbsp;</p>
<p class="western"><span style="font-family: Calibri, sans-serif;">En retour, le CRIB fournit le bulletin de salaire et le document sur les charges p&eacute;riodiques.</span></p>
<p class="western">&nbsp;</p>
<p class="western"><span style="font-family: Calibri, sans-serif;">Le salaire est vir&eacute; par la ligue, si celle-ci a fait ce choix. Sinon il y a un pr&eacute;l&egrave;vement sur son compte et virement sur le compte du salari&eacute;.</span></p>
<p class="western">&nbsp;</p>
<p class="western"><span style="font-family: Calibri, sans-serif;">Pour les versements aux organismes sociaux, il y a pr&eacute;l&egrave;vement direct sur le compte de la ligue.</span></p>
<h4 class="western">&nbsp;</h4>
<h4 class="western"><strong>Formations</strong></h4>
<p class="western" align="justify"><span style="font-family: Calibri, sans-serif;">Le CROSL offre un catalogue diversifi&eacute; de formations aux b&eacute;n&eacute;voles des clubs affili&eacute;s aux ligues (l&eacute;gislation, &eacute;thique, comptabilit&eacute; associative, etc.). Les ligues organisent &eacute;galement des formations, en g&eacute;n&eacute;ral plus techniques, sur l'usage de logiciels sp&eacute;cifiques de gestion des clubs ou des comp&eacute;titions sportives.</span></p>	



					</div>
				</div>
			</div>
</html><?php include 'footer.php'; ?> <html>
</body>	
</html>