	<div class="features">
		<div class="container">
			<h3 class="m_3">Articles</h3>

			  <div class="row">
          <hr>
				<div class="col-md-3 top_box">
				  <div class="view view-ninth"><a href="404.php">
                    <img src="images/pic1.jpg" class="img-responsive" alt=""/>
                    <div class="mask mask-1"> </div>
                    <div class="mask mask-2"> </div>
                      <div class="content">
                        <h2>Nos coachs</h2>
                        <p>Venez vous formez auprès de professionel du sport.</p>
                      </div>
                   </a> </div
                  </div>
                  <h4 class="m_4"><a href="#">Formations</a></h4>
                  <p class="m_5">Decouvrez nos offres!</p>
                </div>
                <div class="col-md-3 top_box">
					<div class="view view-ninth"><a href="presentation.php">
                    <img src="images/pic2.jpg" class="img-responsive" alt=""/>
                    <div class="mask mask-1"> </div>
                    <div class="mask mask-2"> </div>
                      <div class="content">
                        <h2>Exclusive</h2>
                        <p>Decouvrez une interview de notre président.</p>
                      </div>
                    </a> </div>
                   <h4 class="m_4"><a href="#">Présentation</a></h4>
                   <p class="m_5">La M2L en quelques mots.</p>
				</div>
				<div class="col-md-3 top_box">
					<div class="view view-ninth"><a href="recrutement.php">
                    <img src="images/pic3.jpg" class="img-responsive" alt=""/>
                    <div class="mask mask-1"> </div>
                    <div class="mask mask-2"> </div>
                      <div class="content">
                        <h2>Recrutement</h2>
                        <p>Nous sommes à la recheche de profil divers, envoyez-nous votre curriculum vitae.</p>
                      </div>
                    </a> </div>
                   <h4 class="m_4"><a href="#">Offres d'emplois</a></h4>
                   <p class="m_5">Rejoignez-nous</p>
				</div>
				<div class="col-md-3 top_box1">
					<div class="view view-ninth"><a href="404.php">
                    <img src="images/pic4.jpg" class="img-responsive" alt=""/>
                    <div class="mask mask-1"> </div>
                    <div class="mask mask-2"> </div>
                      <div class="content">
                        <h2>Inscription</h2>
                        <p>Inscrivez-vous à nos sessions théoriques et pratiques.</p>
                      </div>
                     </a> </div>
                   <h4 class="m_4"><a href="#">Arbitrage</a></h4>
                   <p class="m_5">Devenez arbitre!</p>
				</div>
			</div>
      <hr>
		 </div>
	    </div>