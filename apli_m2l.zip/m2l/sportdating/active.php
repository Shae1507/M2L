<?php 

    include 'header2.php';

        $id = $_GET['id'];
        $query=$bdd->prepare("UPDATE membres SET actif = '1' WHERE id = '$id'"); 
        $query->execute();
?>

  <!--================Frist Main hader Area =================-->
        
        <!--================Slider Reg Area =================-->
        <section class="slider_area slider_bg">
            <div class=slider_inner>
                <div class="rev_slider fullwidthabanner"  data-version="5.3.0.2" id="home-slider3">
                    <ul> 
                        <li style="background-color: black;" data-slotamount="7" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="600" data-rotate="0" data-saveperformance="off">
                            <!-- MAIN IMAGE -->
                            <!-- LAYERS -->
                            <div class="tp-caption left_img"
                                data-whitespace="nowrap"
                                data-voffset="['0']"
                                data-hoffset="['80','20']"
                                data-x="left"
                                data-y="bottom"
                                data-transform_idle="o:1;"
                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
                                data-start="1800" >
                                <img src="img/fond1.jpg" alt="">
                            </div>
                            <div class="tp-caption first_text" 
                                data-width="none"
                                data-height="none"
                                data-whitespace="nowrap"
                                data-voffset="['300','170']"
                                data-hoffset="['190','0']"
                                data-x="center" 
                                data-y="top"
                                data-fontsize="['48','48','48','28']" 
                                data-lineheight="['55','55','55','35']" 
                                data-transform_idle="o:1;"
                                data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"x:[-100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"
                                data-start="800" 
                                data-splitin="none" 
                                data-splitout="none" 
                                data-responsive_offset="on"><p style="padding-right: 100px;">Venez rejoindre<br /> la communauté</p>
                            </div>
                            <div class="tp-caption secand_text"
                                data-whitespace="nowrap"
                                data-voffset="['430','300','300','260']"
                                data-hoffset="['135','-50','-50','0']"
                                data-x="center"
                                data-transform_idle="o:1;"
                                data-fontsize="['22','22','22','22','18']" 
                                data-lineheight="['30','30','30','30','27']" 
                                 data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                data-y="top"
                                data-start="1800" >
                                <p style="padding-left: 140px;">Inscrivez-vous sur Sos Partenaire <br /> et trouvez rapidement un compagnon de sport</p>
                            </div>
                            <div class="tp-caption third_text"
                                data-voffset="['470','350','350','320']"
                                data-hoffset="['220','30','30','0']"
                                data-whitespace="['nowrap','nowrap','nowrap','normal']"
                                data-width="['','','','100%']"
                                data-x="center"
                                data-fontsize="['16','16','16','20']" 
                                data-lineheight="['26','26','26','30']" 
                                data-transform_idle="o:1;"
                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
                                data-y="top"
                                data-start="1800" > <br />
                                Sos Partenaire est un site de rencontre qui vous permet de trouver <br class="s_br_p" /> les personnes qui pratiquent le même sport que vous dans les alentours. 
                            </div>
                            <div class="tp-caption download_btn"
                                data-whitespace="nowrap"
                                data-voffset="['540','450']"
                                data-hoffset="['38','0']"
                                data-x="center"
                                data-transform_idle="o:1;"
                                data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"x:[-100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"
                                data-y="top"
                                data-start="1800" >
                                <br />
                                <a class="register_angkar_btn" href="#"> Nous rejoindre</a>
                            </div>
                        </li>
                       
                    </ul> 
                </div><!-- END REVOLUTION SLIDER -->
            </div>
        </section>
        <!--================End Slider Reg Area =================-->
        
        <!--================Welcome Area =================-->
        <section class="welcome_area">
            <div class="container">
                <div class="welcome_title">
                    <h3>Bienvenue sur <span>Sos</span>Partenaire</h3>
                    <img src="img/w-title-b.png" alt="">
                </div>
                <div class="row">
                    <div class="col-md-3 col-xs-6">
                        <div class="welcome_item">
                            <img src="img/welcome-icon/w-icon-1.png" alt="">
                            <h4 class="counter">106</h4>
                            <h6>Nombres de membres</h6>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="welcome_item">
                            <img src="img/welcome-icon/w-icon-2.png" alt="">
                            <h4 class="counter">14</h4>
                            <h6>Membres en ligne</h6>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="welcome_item">
                            <img src="img/welcome-icon/w-icon-3.png" alt="">
                            <h4 class="counter">47</h4>
                            <h6>Hommes</h6>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="welcome_item">
                            <img src="img/welcome-icon/w-icon-4.png" alt="">
                            <h4 class="counter">59</h4>
                            <h6>Femmes</h6>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Welcome Area =================-->
        
       
        
        <!--================Find Your Soul Area =================-->
        <section class="find_soul_area">
            <div class="container">
                <div class="welcome_title">
                    <h3>Comment trouver le partenaire de sport idéal</h3>
                    <img src="img/w-title-b.png" alt="">
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="find_soul_item">
                            <img src="img/soul-icon/soul-1.png" alt="">
                            <h4>Inscrivez-vous</h4>
                            <p>Il suffit pour cela de renseigner le sport que vous pratiquez, la ville dans laquelle vous vous trouvez, vos préférences et c'est parti !</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="find_soul_item">
                            <img src="img/soul-icon/soul-2.png" alt="">
                            <h4>Trouvez des partenaires</h4>
                            <p>Une simple recherche suffira pour trouver les personnes qui pratiquent le même sport que le votre, à proximité de chez vous</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="find_soul_item">
                            <img  style="padding-top: 15px;" src="img/soul-icon/soul-3.png" alt="">
                            <h4>Jouez</h4>
                            <p>Fixez une date avec la personne de votre choix, et surtout dépensez-vous bien !</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Find Your Soul Area =================-->
        
       
        
     
     
        
        <!--================Footer Area =================-->
      <?php include 'footer.php'; 

      	sleep(300);
          echo '<script type="text/javascript"> alert("Votre compte a bien été activé"); window.location.href ="connexion.php"; </script>';?>
