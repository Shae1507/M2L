<?php include 'header.php';
 include 'acces.php';  ?> <html>
<title>Epreuve E4</title>

 <div class="main">
      <div class="shop_top">
		<div class="container">
			<h3 class="western" style="color: #FF4500">Epreuve E4</h3></br></br>

<h3 class="western">Documentation</h3></br>
<p> Cliquez sur le bouton ci-dessous afin de télécharger le fichier au format ZIP (à décompresser) l'ensemble de la documentation.</p></br>
<input type="button" value="Télécharger" onclick="window.location='http://m2l.badji.fr/doc_m2l.zip';"></br></br>
<h3 class="western">Application</h3></br>
<p> Cliquez sur le bouton ci-dessous afin de télécharger le fichier au format ZIP (à décompresser) l'application.</p></br>
<input type="button" value="Télécharger" onclick="window.location='http://m2l.badji.fr/apli_m2l.zip';">

			   </div>
		    </div>
		 </div>


</html><?php include 'footer.php'; ?>
