<?php include 'header.php'; ?>
   
 <div class="main">
      <div class="shop_top">
	     <div class="container">
						<form action="traitement.php" method="POST"> 
								<div class="register-top-grid">
										<h3>Informations personnelles</h3>
										<div>
											<span>Nom<label>*</label></span>
											<input type="text" name="nom"> 
										</div>
										<div>
											<span>Prénom<label>*</label></span>
											<input type="text" name="prenom"> 
										</div>
										<div>
											<span>Adresse mail<label>*</label></span>
											<input type="text" name="email"> 
										</div>
										<div>
											<span>Téléphone<label>*</label></span>
											<input type="text" name="telephone"> 
										</div>
										<div class="clear"> </div>
										<div class="clear"> </div>
								</div>
								<div class="clear"> </div>
								<div class="register-bottom-grid">
										<h3>Vous enregistrer</h3>
										<div>
											<span>Mot de passe<label>*</label></span>
											<input type="text" name="mdp">
										</div>
										<div>
											<span>Confirmer votre mot de passe<label>*</label></span>
											<input type="text" name="mdp">
										</div>
										<div>
											<span>Pseudo<label>*</label></span>
											<input type="text" name="pseudo">
										</div>
										<div class="clear"> </div>
								</div>
								<div class="clear"> </div>
								<input type="submit" value="Envoyer">
						</form>
					</div>
		   </div>
	  </div>
	  <div class="footer">
   
	</html><?php include 'footer.php'; ?> <html>
</body>	
</html>