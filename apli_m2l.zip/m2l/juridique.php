<?php include 'header.php'; ?> <html>
<title>Statut juridique</title>

	      <div class="main">
	      	  <div class="shop_top">
	      			<div class="container">
	      				<h3 class="western" style="text-align: justify; color: #FF4500">Statut juridique</h3> <br />
	      				<p class="western" style="text-align: justify; font-family: Calibri, sans-serif;">La Maison des Ligues est un établissement du Conseil Régional. Ce n’est pas une entité juridique en propre.</p> <br />
	      				<p class="western" style="text-align: justify; font-family: Calibri, sans-serif;">Elle est financée à 100 % (pour son fonctionnement et pour la construction récente de l’extension des bâtiments C et D) par le Conseil Régional et sans aucune participation du Conseil Général de Meurthe et Moselle, bien qu’elle abrite un certain nombre de comités départementaux. Une convention de cogestion a été passée entre le Conseil Régional et le Comité Régional Olympique et Sportif de Lorraine pour la gestion de l’outil « Maison des Ligues ». Le CROSL est une association financée par le ministère via le CNDS (Centre National de Développement du Sport).</p> <br />
	      			</div>
				</div>
			</div>
</html><?php include 'footer.php'; ?> <html>
</body>	
</html>