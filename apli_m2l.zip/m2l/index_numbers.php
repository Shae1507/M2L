<div class="some.numbers" style="height: 617px;background:  #272727; text-align:center; color: #FFF;">
  <div class="content_bottom-text" style="margin-left: 25px; margin-right: 25px;">
      <h3 style="padding-top: 25px; color: #FFF;">Quelques chiffres</h3>
        <p style="text-align: left;">Nous avons aujourd’hui 11 500 équipes à raison de 175 sports différent au sein de notre territoire qui évoluent dans les 6500 clubs du comité. Cela représente plus de 525 000 licenciés, dont 400 000 joueurs et joueuses, 76 000 encadrants, 32 700 éducateurs/ entraîneurs et 16 300 arbitres. L’harmonisation de ces équipes et de leurs compétitions ne se ferait pas sans l’aide tant appréciée des 15 000 dirigeants qui, année après année, continuent à contribuer au bon développement du sport sur le territoire.</p></br></br>
              
      <div class="container">
        <div class="row">

           <div class="col-md-3 top_box">
            <div class="c100 p100 big green">
              <span>175</span>
              <div class="slice">
                <div class="bar"></div>
                <div class="fill"></div>
            </div>
          </div>
          <h4 class="m_4">Sports différents au sein du territoire</h4>
        </div>
           <div class="col-md-3 top_box">
            <div class="c100 p100 big orange ">
              <span>6500</span>
              <div class="slice">
                <div class="bar"></div>
                <div class="fill"></div>
            </div>
          </div>
          <h4 class="m_4">Clubs appartenant au comité</h4>
        </div>

                   <div class="col-md-3 top_box">
            <div class="c100 p100 big  ">
              <span>525k</span>
              <div class="slice">
                <div class="bar"></div>
                <div class="fill"></div>
            </div>
          </div>
          <h4 class="m_4">Licenciés, en prenant en compte les joueurs/euses, les encadrants, les éducateurs et les arbitres</h4>
        </div>


                   <div class="col-md-3 top_box1">
            <div class="c100 p100 big jaune">
              <span>15k</span>
              <div class="slice">
                <div class="bar"></div>
                <div class="fill"></div>
            </div>
          </div>
          <h4 class="m_4">Dirigeants aidant à contribuer au développement du sport</h4>
        </div>

      </div>
    </div>
  </div>
</div>