	  <div class="main">
		<div class="content-top">
			<h2>Partenaire</h2>
			<p>Découvrez l'ensemble de nos partenaires, qui nous accompagnent et nous soutiennent dans nos actions.</p>

		<div class="customer-logos">
  <div class="slide"><img src="https://www.solodev.com/assets/carousel/image1.png"></div>
  <div class="slide"><img src="https://www.solodev.com/assets/carousel/image2.png"></div>
  <div class="slide"><img src="https://www.solodev.com/assets/carousel/image3.png"></div>
  <div class="slide"><img src="https://www.solodev.com/assets/carousel/image4.png"></div>
  <div class="slide"><img src="https://www.solodev.com/assets/carousel/image5.png"></div>
  <div class="slide"><img src="https://www.solodev.com/assets/carousel/image6.png"></div>
  <div class="slide"><img src="https://www.solodev.com/assets/carousel/image7.png"></div>
  <div class="slide"><img src="https://www.solodev.com/assets/carousel/image8.png"></div>
</div>
				
		</div>
	</div>